jQuery(function($){
$(window).on('load', function() {
            alert('ddd');
        
	});
}
);